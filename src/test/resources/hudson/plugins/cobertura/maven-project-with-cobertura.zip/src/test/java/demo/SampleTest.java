package demo;
import static org.junit.Assert.*;
import org.junit.Test;
public class SampleTest {
    @Test
    public void add() {
        assertEquals(5, Sample.add(2, 3));
    }
}
