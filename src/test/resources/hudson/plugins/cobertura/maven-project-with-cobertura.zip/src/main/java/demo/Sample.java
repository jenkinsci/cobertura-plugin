package demo;
public class Sample {
    public static int add(int x, int y) {
        return x + y;
    }
}
